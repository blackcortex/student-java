package org.example.gen;

public class GenericService {
}
