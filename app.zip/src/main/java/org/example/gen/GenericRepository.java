package org.example.gen;

public interface GenericRepository {
}
