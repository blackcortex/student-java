package org.example.user;

public enum BloodEnum {
    O_MINUS,O_PLUS,A_MINUS,A_PLUS,B_MINUS,B_PLUS,AB_MINUS,AB_PLUS
}
